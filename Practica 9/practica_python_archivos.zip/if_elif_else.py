x = 15

if x < 10:
    print("Es menor que 10")
elif x == 15:
    print("Es igual a 15")
else:
    print("Es mayor a 10")
