lista = [1, 2, 3, "hola", [10, 20]]

print("Lista completa:", lista)
print("Primer elemento:", lista[0])
print("Último elemento:", lista[-1])

lista.append("nuevo")
print("Después de append:", lista)

lista[1] = 99
print("Modificada:", lista)
