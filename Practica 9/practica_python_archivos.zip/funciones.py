def sumar(a, b):
    return a + b

def valores():
    return 10, 20, 30

print("Suma:", sumar(3, 4))

x, y, _ = valores()
print("Valores recibidos:", x, y)
