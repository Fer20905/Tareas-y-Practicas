lista = ["a", "b", "c"]

for elemento in lista:
    print(elemento)
