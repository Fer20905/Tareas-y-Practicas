import math

print("Pi:", math.pi)
print("Raíz de 25:", math.sqrt(25))
