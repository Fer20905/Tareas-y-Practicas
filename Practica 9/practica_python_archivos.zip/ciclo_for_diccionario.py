dic = {"x": 10, "y": 20, "z": 30}

for llave, valor in dic.items():
    print(llave, "=", valor)
