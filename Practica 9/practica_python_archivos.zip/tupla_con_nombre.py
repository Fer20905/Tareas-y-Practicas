from collections import namedtuple

Persona = namedtuple("Persona", "nombre edad ciudad")

p = Persona("Ana", 22, "CDMX")
print(p)
print("Nombre:", p.nombre)
