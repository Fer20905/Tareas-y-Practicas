dic = {"nombre": "Luis", "edad": 20, "escuela": "FI"}

print("Diccionario:", dic)
print("Nombre:", dic["nombre"])

dic["edad"] = 21
print("Diccionario modificado:", dic)

for llave, valor in dic.items():
    print(llave, ":", valor)
