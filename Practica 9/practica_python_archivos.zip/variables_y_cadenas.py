# Variables
x = 10
y = 3.5
nombre = "Juan"

print("x =", x)
print("y =", y)
print("Nombre:", nombre)

# Cadenas y format
print("Hola {} tienes {} años".format(nombre, x))
print("{1} es mayor que {0}".format(x, y))
