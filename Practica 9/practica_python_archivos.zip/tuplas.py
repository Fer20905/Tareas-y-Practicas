tupla = (10, 20, 30)
print("Tupla:", tupla)
print("Primer valor:", tupla[0])

tupla2 = 1, 2, 3
print("Tupla sin paréntesis:", tupla2)
