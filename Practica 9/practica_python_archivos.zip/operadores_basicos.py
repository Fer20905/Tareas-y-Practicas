a = 15
b = 4

print("Suma:", a + b)
print("Resta:", a - b)
print("Multiplicación:", a * b)
print("División:", a / b)

print("Comparaciones:")
print(a > b, a < b, a == b)

print("Booleanos:")
print(True and False)
print(True or False)
print(not False)
